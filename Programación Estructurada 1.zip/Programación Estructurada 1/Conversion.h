#ifndef CONVERSION_H
#define CONVERSION_H

class Conversion
{
public:
    double KilometrosAMillas(double Kilometros);
    double LibrasAKilos(double Libras);
};

#endif /* CONVERSION_H */