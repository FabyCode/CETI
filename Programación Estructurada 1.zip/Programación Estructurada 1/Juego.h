#ifndef JUEGO_H
#define JUEGO_H

class Juego
{
public:
    void Adivinador();
    char JuegoBalero(char c);
};

#endif