#ifndef FECHA_H
#define FECHA_H

class Fecha
{
public:
    int Anio(long f);
    int Dia(long f);
    int Mes(long f);
    int bisiesto(int anio);
};

#endif /* FECHA_H */