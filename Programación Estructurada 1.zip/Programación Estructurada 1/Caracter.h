#ifndef CARACTER_H
#define CARACTER_H

class Caracter
{
public:
    int  CaracterRespectom(char c);
    char CaracterRespectomC(char c);
    void CaracterRespectomC(char c, char* r);
    bool OrdenCaracteres(char c1, char c2);
    void CaracterRespectoIM(char c, char* r);
};

#endif /* CARACTER_H */