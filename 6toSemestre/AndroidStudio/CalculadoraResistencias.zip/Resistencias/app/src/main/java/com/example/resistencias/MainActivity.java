package com.example.resistencias;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.content.Intent;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    TextView band1, band2, band3, tolerancia;
    Integer b1, b2, b3, t;
    String ban1, ban2, ban3, toler;
    Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        band1=findViewById(R.id.banda1);
        band2=findViewById(R.id.banda2);
        band3=findViewById(R.id.banda3);
        tolerancia=findViewById(R.id.banda4);
        toolbar=findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
    }

    public boolean onCreateOptionsMenu (Menu menu)
    {
        getMenuInflater().inflate(R.menu.menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item)
    {
        if(item.getItemId() == R.id.item)
        {
            Intent intent = new Intent(this, ayuda.class);
            startActivity(intent);
        }
        if(item.getItemId() == R.id.item2)
        {
            Intent intent = new Intent(this, creditos.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }
    public void c10(View view){
        b1=0;
        ban1="Negro";
        band1.setText(ban1);
    }

    public void c11(View view) {
        b1=1;
        ban1="Café";
        band1.setText(ban1);
    }

    public void c12(View view) {
        b1=2;
        ban1="Rojo";
        band1.setText(ban1);
    }

    public void c13(View view) {
        b1=3;
        ban1="Naranja";
        band1.setText(ban1);
    }

    public void c14(View view) {
        b1=4;
        ban1="Amarilla";
        band1.setText(ban1);
    }

    public void c15(View view) {
        b1=5;
        ban1="Verde";
        band1.setText(ban1);
    }

    public void c16(View view) {
        b1=6;
        ban1="Azul";
        band1.setText(ban1);
    }

    public void c17(View view) {
        b1=7;
        ban1="Morado";
        band1.setText(ban1);
    }

    public void c18(View view) {
        b1=8;
        ban1="Gris";
        band1.setText(ban1);
    }

    public void c19(View view) {
        b1=9;
        ban1="Blanco";
        band1.setText(ban1);
    }

    public void c20(View view) {
        b2 = 0;
        ban2 = "Negro";
        band2.setText(ban2);
    }

    public void c21(View view) {
        b2 = 1;
        ban2 = "Café";
        band2.setText(ban2);
    }

    public void c22(View view) {
        b2 = 2;
        ban2 = "Rojo";
        band2.setText(ban2);
    }

    public void c23(View view) {
        b2 = 3;
        ban2 = "Naranja";
        band2.setText(ban2);
    }

    public void c24(View view) {
        b2 = 4;
        ban2 = "Amarilla";
        band2.setText(ban2);
    }

    public void c25(View view) {
        b2 = 5;
        ban2 = "Verde";
        band2.setText(ban2);
    }

    public void c26(View view) {
        b2 = 6;
        ban2 = "Azul";
        band2.setText(ban2);
    }

    public void c27(View view) {
        b2 = 7;
        ban2 = "Morado";
        band2.setText(ban2);
    }

    public void c28(View view) {
        b2 = 8;
        ban2 = "Gris";
        band2.setText(ban2);
    }

    public void c29(View view) {
        b2 = 9;
        ban2 = "Blanco";
        band2.setText(ban2);
    }

    public void c30(View view) {
        b3 = 0;
        ban3 = "Negro";
        band3.setText(ban3);
    }

    public void c31(View view) {
        b3 = 1;
        ban3 = "Café";
        band3.setText(ban3);
    }

    public void c32(View view) {
        b3 = 2;
        ban3 = "Rojo";
        band3.setText(ban3);
    }

    public void c33(View view) {
        b3 = 3;
        ban3 = "Naranja";
        band3.setText(ban3);
    }

    public void c34(View view) {
        b3 = 4;
        ban3 = "Amarilla";
        band3.setText(ban3);
    }

    public void c35(View view) {
        b3 = 5;
        ban3 = "Verde";
        band3.setText(ban3);
    }

    public void c36(View view) {
        b3 = 6;
        ban3 = "Azul";
        band3.setText(ban3);
    }

    public void c37(View view) {
        b3 = 7;
        ban3 = "Morado";
        band3.setText(ban3);
    }

    public void c38(View view) {
        b3 = 8;
        ban3 = "Gris";
        band3.setText(ban3);
    }

    public void c39(View view) {
        b3 = 9;
        ban3 = "Blanco";
        band3.setText(ban3);
    }

    public void t0(View view) {
        t = 1;
        toler = "Café";
        tolerancia.setText(toler);
    }

    public void t1(View view) {
        t = 2;
        toler = "Rojo";
        tolerancia.setText(toler);
    }

    public void t2(View view) {
        t = 5;
        toler = "Plata";
        tolerancia.setText(toler);
    }

    public void t3(View view) {
        t = 10;
        toler = "Dorado";
        tolerancia.setText(toler);
    }

    public void calculation(View view)
    {
        if (TextUtils.isEmpty(ban1) || TextUtils.isEmpty(ban2) || TextUtils.isEmpty(ban3) || TextUtils.isEmpty(toler))
        {
            Toast.makeText(MainActivity.this, "Selecciona al menos un color por banda", Toast.LENGTH_SHORT).show();
        }
        else
        {
            Intent intent = new Intent(this, MainActivity2.class);
            intent.putExtra("b1", b1);
            intent.putExtra("b2", b2);
            intent.putExtra("b3", b3);
            intent.putExtra("t", t);
            startActivity(intent);
        }
    }
}