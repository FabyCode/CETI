package com.example.resistencias;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    String res;
    TextView val;
    Toolbar toolbar;
    Integer b1, b2, b3, t;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        val=findViewById(R.id.valor);
        toolbar=findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        llego();
        logica();
    }//onCreate
    private void llego()
    {
        b1 = getIntent().getIntExtra("b1", 0);
        b2 = getIntent().getIntExtra("b2", 0);
        b3 = getIntent().getIntExtra("b3", 0);
        t = getIntent().getIntExtra("t", 0);
    }

    private void logica()
    {
        if(b1!=0) {
            switch (b3) {
                case 0:
                    res = "" + b1 + b2 + "Ω ±" + t + "%";
                    val.setText(res);
                    break;
                case 1:
                    res = "" + b1 + b2 + "0Ω ±" + t + "%";
                    val.setText(res);
                    break;
                case 2:
                    res = "" + b1 + "." + b2 + "KΩ ±" + t + "%";
                    val.setText(res);
                    break;
                case 3:
                    res = "" + b1 + b2 + "KΩ ±" + t + "%";
                    val.setText(res);
                    break;
                case 4:
                    res = "" + b1 + b2 + "0KΩ ±" + t + "%";
                    val.setText(res);
                    break;
                case 5:
                    res = "" + b1 + "." + b2 + "MΩ ±" + t + "%";
                    val.setText(res);
                    break;
                case 6:
                    res = "" + b1 + b2 + "MΩ ±" + t + "%";
                    val.setText(res);
                    break;
                case 7:
                    res = "" + b1 + b2 + "0MΩ ±" + t + "%";
                    val.setText(res);
                    break;
                case 8:
                    res = "" + b1 + "." + b2 + "GΩ ±" + t + "%";
                    val.setText(res);
                    break;
                case 9:
                    res = "" + b1 + b2 + "GΩ ±" + t + "%";
                    val.setText(res);
                    break;
            }//switch
        }//if b1!=0
        else if(b1==0) {
            switch (b3) {
                case 0:
                    res = "" + b2 + "Ω ±" + t + "%";
                    val.setText(res);
                    break;
                case 1:
                    res = "" + b2 + "0Ω ±" + t + "%";
                    val.setText(res);
                    break;
                case 2:
                    res = "" + b2 + "00Ω ±" + t + "%";
                    val.setText(res);
                    break;
                case 3:
                    res = "" + b2 + "KΩ ±" + t + "%";
                    val.setText(res);
                    break;
                case 4:
                    res = "" + b2 + "0KΩ ±" + t + "%";
                    val.setText(res);
                    break;
                case 5:
                    res = "" + b2 + "00KΩ ±" + t + "%";
                    val.setText(res);
                    break;
                case 6:
                    res = "" + b2 + "MΩ ±" + t + "%";
                    val.setText(res);
                    break;
                case 7:
                    res = "" +  b2 + "0MΩ ±" + t + "%";
                    val.setText(res);
                    break;
                case 8:
                    res = "" + b2 + "00MΩ ±" + t + "%";
                    val.setText(res);
                    break;
                case 9:
                    res = "" + b2 + "GΩ ±" + t + "%";
                    val.setText(res);
                    break;
            }//switch
        }//if b1!=0
    }
    public boolean onCreateOptionsMenu (Menu menu)
    {
        getMenuInflater().inflate(R.menu.menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item)
    {
        if(item.getItemId() == R.id.item)
        {
            Intent intent = new Intent(this, ayuda.class);
            startActivity(intent);
        }
        if(item.getItemId() == R.id.item2)
        {
            Intent intent = new Intent(this, creditos.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }
    public void volver(View view) {
        //finish();
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}