package com.example.donjericallo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Calendar;

import Global.Info;
import Pojo.Pedidos;

public class Modificar extends AppCompatActivity {
    EditText nom, ape, can, dir, fec, tel, tie;
    Spinner tip;
    ListView estado;
    Button next, back, save;
    Toolbar toolbar;
    int pos;
    Pedidos Persona;
    SharedPreferences archivo;
    String selectedItem;
    private int year, month, day, hour, minutos;
    private static final int DATE_PICKER_ID = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modificar);
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        nom = findViewById(R.id.modNom);
        ape = findViewById(R.id.modApe);
        tip = findViewById(R.id.sp_modTipo);
        can = findViewById(R.id.modCant);
        dir = findViewById(R.id.modDir);
        fec = findViewById(R.id.modFec);
        tel = findViewById(R.id.modTel);
        tie = findViewById(R.id.modHor);
        estado = findViewById(R.id.list_estado);

        String[] opcionesTipo = {"Jericalla", "Flan"};
        ArrayAdapter<String> adapterTipo = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, opcionesTipo);
        adapterTipo.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        tip.setAdapter(adapterTipo);

        String[] opcionesEstado = {"Pendiente", "Listo"};
        ArrayAdapter<String> adapterEstado = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, opcionesEstado);
        estado.setAdapter(adapterEstado);

        final Calendar c = Calendar.getInstance();
        year = c.get(Calendar.YEAR);
        month = c.get(Calendar.MONTH);
        day = c.get(Calendar.DAY_OF_MONTH);

        fec.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDialog(DATE_PICKER_ID);
            }
        });

        tie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tiempo();
            }
        });

        estado.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                selectedItem = ((TextView) view).getText().toString();
                Toast.makeText(Modificar.this, "Seleccionaste: " + selectedItem, Toast.LENGTH_SHORT).show();
            }
        });

        back = findViewById(R.id.bt_back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onClickAnterior();
            }
        });
        save = findViewById(R.id.bt_save);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onClickGuardar();
            }
        });
        next = findViewById(R.id.bt_next);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onClickSiguiente();
            }
        });

        pos = 0;
        if (Info.lista.size() > 0) {
            Persona = Info.lista.get(0);
            imprime(Persona);
        }
    }

    private void tiempo() {
        int hora, minuto;
        Calendar actual = Calendar.getInstance();
        hora = actual.get(Calendar.HOUR_OF_DAY);
        minuto = actual.get(Calendar.MINUTE);

        TimePickerDialog tpd = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                hour = hourOfDay;
                minutos = minute;
                tie.setText(new StringBuilder().append(hour).append(":").append(minutos));
            }
        }, hora, minuto, true);
        tpd.show();
    }

    @Override
    protected Dialog onCreateDialog(int id) {
        if (id == DATE_PICKER_ID) {
            return new DatePickerDialog(this, datePickerListener, year, month, day);
        }
        return null;
    }
    private DatePickerDialog.OnDateSetListener datePickerListener
            = new DatePickerDialog.OnDateSetListener() {
        public void onDateSet(DatePicker view, int selectedYear,
                              int selectedMonth, int selectedDay) {
            year = selectedYear;
            month = selectedMonth;
            day = selectedDay;
            updateDateDisplay();
        }
    };
    private void updateDateDisplay() {
        fec.setText(new StringBuilder()
                .append(year).append("-")
                .append(month + 1).append("-")
                .append(day));
    }
    private void imprime(Pedidos p)
    {
        nom.setText(p.getNombre());
        ape.setText(p.getApellido());
        can.setText(p.getCantidad());
        dir.setText(p.getDireccion());
        fec.setText(p.getFecha());
        tel.setText(p.getTelefono());
        tie.setText(p.getTiempo());

        String tipoSeleccionado = p.getTipo();
        ArrayAdapter<String> adapterTipo = (ArrayAdapter<String>) tip.getAdapter();
        int posicionTipo = adapterTipo.getPosition(tipoSeleccionado);
        tip.setSelection(posicionTipo);
    }

    private void onClickSiguiente()
    {
        if(Info.lista.size() > 0) {
            if (pos == Info.lista.size() - 1) {
                pos = 0;
            } else {
                pos++;
            }
            Persona = Info.lista.get(pos);
            imprime(Persona);
        }
    }

    private void onClickGuardar()
    {
        if(Info.lista.size() > 0) {
            Persona.setNombre(nom.getText().toString());
            Persona.setApellido(ape.getText().toString());
            Persona.setCantidad(can.getText().toString());
            Persona.setTelefono(tel.getText().toString());
            Persona.setTipo(tip.getSelectedItem().toString());
            Persona.setEstado(selectedItem);
            Persona.setFecha(fec.getText().toString());
            Persona.setDireccion(dir.getText().toString());
            Persona.setTiempo(tie.getText().toString());
            
            update();
        }
    }

    private void update() {
        String baseUrl = "http://192.168.84.78/dj/update.php?id=" + Persona.getId();
        String url = baseUrl;

        try {
            String encodedNombre = URLEncoder.encode(nom.getText().toString(), "UTF-8");
            String encodedApellido = URLEncoder.encode(ape.getText().toString(), "UTF-8");
            String encodedDireccion = URLEncoder.encode(dir.getText().toString(), "UTF-8");

            url += "&nombre=" + encodedNombre +
                    "&apellido=" + encodedApellido +
                    "&pedido=" + URLEncoder.encode(tip.getSelectedItem().toString(), "UTF-8") +
                    "&cantidad=" + can.getText().toString() +
                    "&direccion=" + encodedDireccion +
                    "&entrega=" + fec.getText().toString() +
                    "&telefono=" + tel.getText().toString() +
                    "&estado=" + selectedItem;

            Log.d("URL_DEBUG", "URL mod: " + url);

            JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, url, null,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            Toast.makeText(Modificar.this, "Registro actualizado correctamente", Toast.LENGTH_SHORT).show();
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Log.e("Modificar", "Error en la solicitud al servidor: " + error.getMessage());
                            Toast.makeText(Modificar.this, "Error al actualizar el registro", Toast.LENGTH_SHORT).show();
                        }
                    });

            RequestQueue requestQueue = Volley.newRequestQueue(this);
            requestQueue.add(jsonObjectRequest);

        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }

    private void onClickAnterior()
    {
        if(Info.lista.size() > 0) {
            if (pos == 0) {
                pos = Info.lista.size() - 1;
            } else {
                pos--;
            }
            Persona = Info.lista.get(pos);
            imprime(Persona);
        }
    }

    public boolean onCreateOptionsMenu (Menu menu)
    {
        getMenuInflater().inflate(R.menu.menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item)
    {
        if(item.getItemId() == R.id.item)
        {
            Intent pedidos = new Intent(this, Mostrar.class);
            startActivity(pedidos);
            finish();
        }
        if(item.getItemId() == R.id.item2)
        {
            finish();
        }
        if(item.getItemId() == R.id.item3)
        {
            Toast.makeText(Modificar.this, "Ya se encuentra en la activity", Toast.LENGTH_SHORT).show();
        }
        if(item.getItemId() == R.id.item4)
        {
            Intent delet = new Intent(this, Eliminar.class);
            startActivity(delet);
            finish();
        }
        if(item.getItemId() == R.id.item5)
        {
            if(archivo.contains("id_usuario")){
                SharedPreferences.Editor editor = archivo.edit();
                editor.remove("id_usuario");
                editor.commit();
                Intent fin = new Intent(this, RealMain.class);
                startActivity(fin);
                finish();
            }
        }
        return super.onOptionsItemSelected(item);
    }
}