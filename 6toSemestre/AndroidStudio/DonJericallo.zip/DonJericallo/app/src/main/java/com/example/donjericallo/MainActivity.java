package com.example.donjericallo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TimePicker;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Calendar;

import Global.Info;
import Pojo.Pedidos;

public class MainActivity extends AppCompatActivity {
    Toolbar toolbar;
    SharedPreferences archivo;
    EditText nombre, apellido, cantidad, direccion, telefono, instrucciones, fecha, tiempo;
    Spinner sp_tipo, sp_pago;
    Button agregar;
    String tipo, pago;
    private int year, month, day, hour, minutos;
    private static final int DATE_PICKER_ID = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(getResources().getColor(R.color.main_color));

        nombre = findViewById(R.id.regNom);
        apellido = findViewById(R.id.regApe);
        cantidad = findViewById(R.id.regCant);
        direccion = findViewById(R.id.regDir);
        telefono = findViewById(R.id.regTel);
        instrucciones = findViewById(R.id.regEsp);
        sp_tipo = findViewById(R.id.spinTipo);
        sp_pago = findViewById(R.id.spinPago);
        fecha = findViewById(R.id.regDate);
        tiempo = findViewById(R.id.regTime);
        agregar = findViewById(R.id.bt_add);

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        String[] opcionesPago = {"Crédito/Débito", "Efectivo"};
        ArrayAdapter<String> adapterPago = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, opcionesPago);
        adapterPago.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp_pago.setAdapter(adapterPago);

        String[] opcionesTipo = {"Jericalla", "Flan"};
        ArrayAdapter<String> adapterTipo = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, opcionesTipo);
        adapterTipo.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp_tipo.setAdapter(adapterTipo);

        archivo=this.getSharedPreferences("sesion", Context.MODE_PRIVATE);

        final Calendar c = Calendar.getInstance();
        year = c.get(Calendar.YEAR);
        month = c.get(Calendar.MONTH);
        day = c.get(Calendar.DAY_OF_MONTH);

        fecha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDialog(DATE_PICKER_ID);
            }
        });

        tiempo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tiempo();
            }
        });

        agregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { agregarClick(); }
        });

        obtener();
    }

    private void tiempo() {
        int hora, minuto;
        Calendar actual = Calendar.getInstance();
        hora = actual.get(Calendar.HOUR_OF_DAY);
        minuto = actual.get(Calendar.MINUTE);

        TimePickerDialog tpd = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                hour = hourOfDay;
                minutos = minute;

                tiempo.setText(new StringBuilder().append(hour).append(":").append(minutos));
            }
        }, hora, minuto, true);
        tpd.show();
    }

    private void obtener() {
        String urlGet = "http://192.168.84.78/dj/select.php";
        RequestQueue queue = Volley.newRequestQueue(MainActivity.this);
        JsonArrayRequest jsonArray = new JsonArrayRequest(Request.Method.GET, urlGet, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        try {
                            for (int i = 0; i < response.length(); i++) {
                                JSONObject registro = response.getJSONObject(i);
                                Pedidos pedidos = new Pedidos();
                                pedidos.setId(registro.getInt("ticket"));
                                pedidos.setNombre(registro.getString("Nombre"));
                                pedidos.setApellido(registro.getString("Apellido"));
                                pedidos.setTipo(registro.getString("Pedido"));
                                pedidos.setCantidad(registro.getString("Cantidad"));
                                pedidos.setDireccion(registro.getString("Direccion"));
                                pedidos.setFecha(registro.getString("Entrega"));
                                pedidos.setTelefono(registro.getString("Telefono"));
                                pedidos.setPago(registro.getString("Pago"));
                                pedidos.setEstado(registro.getString("Estado"));
                                pedidos.setInstrucciones(registro.getString("Instrucciones"));

                                Info.lista.add(pedidos);
                            }
                        } catch (JSONException e) {
                            throw new RuntimeException(e);
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {Log.d("Obtener", error.getMessage());}
        });
        queue.add(jsonArray);
    }

    private void agregarClick()
    {
        tipo = sp_tipo.getSelectedItem().toString();
        pago = sp_pago.getSelectedItem().toString();

        String baseUrl = "http://192.168.84.78/dj/insert.php";
        String url = baseUrl;

        try {
            String encodedNombre = URLEncoder.encode(nombre.getText().toString(), "UTF-8");
            String encodedApellido = URLEncoder.encode(apellido.getText().toString(), "UTF-8");
            String encodedDireccion = URLEncoder.encode(direccion.getText().toString(), "UTF-8");
            String encodedInstrucciones = URLEncoder.encode(instrucciones.getText().toString(), "UTF-8");

            url += "?nombre=" + encodedNombre +
                    "&apellido=" + encodedApellido +
                    "&pedido=" + URLEncoder.encode(tipo, "UTF-8") +
                    "&cantidad=" + cantidad.getText().toString() +
                    "&direccion=" + encodedDireccion +
                    "&entrega=" + fecha.getText().toString() +
                    "&telefono=" + telefono.getText().toString() +
                    "&pago=" + URLEncoder.encode(pago, "UTF-8") +
                    "&estado=Pendiente" +
                    "&instrucciones=" + encodedInstrucciones;
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        Log.d("URL_DEBUG", "URL insert: " + url);

        JsonObjectRequest pet = new JsonObjectRequest
                (Request.Method.GET, url, null,
                        new Response.Listener<JSONObject>() {
                            @Override
                            public void onResponse(JSONObject response) {
                                try {
                                    if (response.getInt("ticket") != -1) {
                                        int id = response.getInt("ticket");
                                        String estado = "Pendiente";
                                        Pedidos persona = new Pedidos();
                                        persona.setNombre(nombre.getText().toString());
                                        persona.setApellido(apellido.getText().toString());
                                        persona.setCantidad(cantidad.getText().toString());
                                        persona.setDireccion(direccion.getText().toString());
                                        persona.setTelefono(telefono.getText().toString());
                                        persona.setInstrucciones(instrucciones.getText().toString());
                                        persona.setFecha(fecha.getText().toString());
                                        persona.setEstado(estado);
                                        persona.setTipo(tipo);
                                        persona.setPago(pago);
                                        persona.setTiempo(tiempo.getText().toString());
                                        persona.setId(id);
                                        Info.lista.add(persona);

                                        nombre.setText("");
                                        apellido.setText("");
                                        cantidad.setText("");
                                        direccion.setText("");
                                        telefono.setText("");
                                        instrucciones.setText("");
                                        fecha.setText("");
                                    } else {
                                        nombre.setText("");
                                        apellido.setText("");
                                        cantidad.setText("");
                                        direccion.setText("");
                                        telefono.setText("");
                                        instrucciones.setText("");
                                        fecha.setText("");
                                    }
                                } catch (JSONException e) {
                                    throw new RuntimeException(e);
                                }
                                Toast.makeText(MainActivity.this, response.toString(), Toast.LENGTH_SHORT).show();
                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d("tu", error.getMessage());
                    }
                });
        RequestQueue lanzarPeticion = Volley.newRequestQueue(this);
        lanzarPeticion.add(pet);
    }



    @Override
    protected Dialog onCreateDialog(int id) {
        if (id == DATE_PICKER_ID) {
            return new DatePickerDialog(this, datePickerListener, year, month, day);
        }
        return null;
    }
    private DatePickerDialog.OnDateSetListener datePickerListener
            = new DatePickerDialog.OnDateSetListener() {
        public void onDateSet(DatePicker view, int selectedYear,
                              int selectedMonth, int selectedDay) {
            year = selectedYear;
            month = selectedMonth;
            day = selectedDay;

            updateDateDisplay();
        }
    };
    private void updateDateDisplay() {
        fecha.setText(new StringBuilder()
                .append(year).append("-")
                .append(month + 1).append("-")
                .append(day));
    }
    public boolean onCreateOptionsMenu (Menu menu)
    {
        getMenuInflater().inflate(R.menu.menu,menu);
        return super.onCreateOptionsMenu(menu);
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item)
    {
        if(item.getItemId() == R.id.item)
        {
            Intent pedidos = new Intent(this, Mostrar.class);
            startActivity(pedidos);
        }
        if(item.getItemId() == R.id.item2)
        {
            Toast.makeText(MainActivity.this, "Ya se encuentra en la activity", Toast.LENGTH_SHORT).show();
        }
        if(item.getItemId() == R.id.item3)
        {
            Intent modi = new Intent(this, Modificar.class);
            startActivity(modi);
        }
        if(item.getItemId() == R.id.item4)
        {
            Intent delet = new Intent(this, Eliminar.class);
            startActivity(delet);
        }
        if(item.getItemId() == R.id.item5)
        {
            if(archivo.contains("id_usuario")){
                SharedPreferences.Editor editor = archivo.edit();
                editor.remove("id_usuario");
                editor.commit();
                Intent fin = new Intent(this, RealMain.class);
                startActivity(fin);
                finish();
            }
        }
        return super.onOptionsItemSelected(item);
    }
}