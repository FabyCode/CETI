package Adaptador;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.donjericallo.Card;
import com.example.donjericallo.R;

import org.json.JSONArray;

import Global.Info;

public class AdaptadorVer extends RecyclerView.Adapter<AdaptadorVer.MiActivity>
{
    public Context context;
    @NonNull
    @Override
    public MiActivity onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        View v = View.inflate(context, R.layout.listita, null);
        MiActivity obj = new MiActivity(v);
        return obj;
    }

    @Override
    public void onBindViewHolder(@NonNull MiActivity holder, int i) {
        final int pos = i;

        holder.nom.setText((Info.lista.get(i).getNombre()));
        holder.tip.setText((Info.lista.get(i).getTipo()));
        holder.can.setText((Info.lista.get(i).getCantidad()));
        holder.dir.setText((Info.lista.get(i).getDireccion()));
        holder.tel.setText((Info.lista.get(i).getTelefono()));
        holder.ape.setText((Info.lista.get(i).getApellido()));
        //holder.fec.setText((Info.lista.get(i).getFecha()));
        holder.pag.setText((Info.lista.get(i).getPago()));
        //holder.est.setText((Info.lista.get(i).getEstado()));

        holder.ojopiojo.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View view) {
                Intent card = new Intent(context, Card.class);
                card.putExtra("pos", pos);
                context.startActivity(card);
            }
        });
    }

    @Override
    public int getItemCount() {return Info.lista.size();}

    public class MiActivity extends RecyclerView.ViewHolder
    {
        TextView nom, ape, tip, can, dir, fec, tel, pag, est;
        Button ojopiojo;
        public MiActivity(@NonNull View itemView)
        {
            super(itemView);
            nom = itemView.findViewById(R.id.CardNom);
            ape = itemView.findViewById(R.id.CardApe);
            tip = itemView.findViewById(R.id.CardTipo);
            can = itemView.findViewById(R.id.CardCant);
            dir = itemView.findViewById(R.id.CardDire);
            //fec = itemView.findViewById(R.id.CardFec);
            pag = itemView.findViewById(R.id.CardPago);
            tel = itemView.findViewById(R.id.CardTel);
            //est = itemView.findViewById(R.id.CardTel);
            ojopiojo = itemView.findViewById(R.id.bt_ojopiojo);
        }
    }
}
