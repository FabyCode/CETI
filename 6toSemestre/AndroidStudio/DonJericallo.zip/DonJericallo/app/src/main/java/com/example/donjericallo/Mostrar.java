package com.example.donjericallo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;

import Adaptador.AdaptadorVer;

public class Mostrar extends AppCompatActivity {
    RecyclerView rv;
    Toolbar toolbar;
    SharedPreferences archivo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_mostrar);
        rv = findViewById(R.id.recycler);
        AdaptadorVer av = new AdaptadorVer();
        av.context = this;
        LinearLayoutManager llm = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        rv.setLayoutManager(llm);
        rv.setAdapter(av);

        archivo=this.getSharedPreferences("sesion", Context.MODE_PRIVATE);
        toolbar=findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        select();
    }

    private void select() {
        String url = "http://192.168.100.70/dj/select.php";

        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("Mostrar", "Error al obtener registros: " + error.getMessage());
                    }
                });

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(jsonArrayRequest);
    }

    public boolean onCreateOptionsMenu (Menu menu)
    {
        getMenuInflater().inflate(R.menu.menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item)
    {
        if(item.getItemId() == R.id.item)
        {
            Toast.makeText(Mostrar.this, "Ya se encuentra en la activity", Toast.LENGTH_SHORT).show();
        }
        if(item.getItemId() == R.id.item2)
        {
            finish();
        }
        if(item.getItemId() == R.id.item3)
        {
            Intent modi = new Intent(this, Modificar.class);
            startActivity(modi);
            finish();
        }
        if(item.getItemId() == R.id.item4)
        {
            Intent delet = new Intent(this, Eliminar.class);
            startActivity(delet);
            finish();
        }
        if(item.getItemId() == R.id.item5)
        {
            if(archivo.contains("id_usuario")){
                SharedPreferences.Editor editor = archivo.edit();
                editor.remove("id_usuario");
                editor.commit();
                Intent fin = new Intent(this, RealMain.class);
                startActivity(fin);
                finish();
            }
        }
        return super.onOptionsItemSelected(item);
    }
}

