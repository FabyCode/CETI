package Global;

import java.util.ArrayList;
import Pojo.Pedidos;

public class Info
{
    public static final ArrayList<Pedidos> lista = new ArrayList<>();
    public static final ArrayList<Pedidos> ListaBaja = new ArrayList<>();
}
