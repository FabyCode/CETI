package com.example.donjericallo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import Global.Info;

public class Card extends AppCompatActivity {
    TextView cnom, ctel, ctipo, cdir, cinstru;
    Button call;
    String estado;
    View estado_v;
    int i;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_card);

        cnom = findViewById(R.id.ExtraNom);
        ctel = findViewById(R.id.ExtraTel);
        ctipo = findViewById(R.id.ExtraTipo);
        cdir = findViewById(R.id.ExtraDire);
        cinstru = findViewById(R.id.ExtraInstruc);
        call = findViewById(R.id.bt_call);
        estado_v = findViewById(R.id.estado_view);
        i = getIntent().getIntExtra("pos", -1);
        estado = Info.lista.get(i).getEstado();

        call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { onclickLlamar(); }
        });

        cnom.setText(Info.lista.get(i).getNombre());
        ctel.setText(Info.lista.get(i).getTelefono());
        ctipo.setText(Info.lista.get(i).getTipo());
        cdir.setText(Info.lista.get(i).getDireccion());
        cinstru.setText(Info.lista.get(i).getInstrucciones());

        cambiarColorFondo();
    }

    private void cambiarColorFondo()
    {
        if (estado.equals("Pendiente")) {
            estado_v.setBackgroundColor(Color.parseColor("#FFDE59"));
        } else if (estado.equals("Listo")) {
            estado_v.setBackgroundColor(Color.parseColor("#7ED957"));
        }
    }

    private void onclickLlamar()
    {
        Intent llamar = new Intent(Intent.ACTION_CALL);
        llamar.setData(Uri.parse("tel:"+ctel.getText().toString()));
        if(ActivityCompat.checkSelfPermission
                (this, android.Manifest.permission.CALL_PHONE)
                != PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(this, new String[]
                    {Manifest.permission.CALL_PHONE}, 10);
            return;
        }
        startActivity(llamar);
    }
}