package com.example.donjericallo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class RealMain extends AppCompatActivity {
    EditText user, pass;
    Button login;
    SharedPreferences archivo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_real_main);

        user = findViewById(R.id.user);
        pass = findViewById(R.id.pass);
        login = findViewById(R.id.bt_login);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { loginClick(); }
        });

        archivo=this.getSharedPreferences("sesion", Context.MODE_PRIVATE);
        if(archivo.contains("id_usuario")){
            Intent ini = new Intent(this, MainActivity.class);
            startActivity(ini);
            finish();
        }
        pass.setOnEditorActionListener((textView, actionId, keyEvent) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE ||
                    (keyEvent.getAction() == KeyEvent.ACTION_DOWN &&
                            keyEvent.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                loginClick();
                return true;
            }
            return false;
        });
    }

    private void loginClick()
    {
        String url = "http://192.168.84.78/dj/ingreso.php?usr=";
        url = url + user.getText().toString();
        url = url + "&pass=";
        url = url + pass.getText().toString();

        JsonObjectRequest pet = new JsonObjectRequest
                (Request.Method.GET, url, null,
                        new Response.Listener<JSONObject>() {
                            @Override
                            public void onResponse(JSONObject response) {
                                try {
                                    if (response.getInt("usr") != -1) {
                                        Intent in = new Intent(RealMain.this, MainActivity.class);
                                        SharedPreferences.Editor editor = archivo.edit();
                                        editor.putInt("id_usuario", response.getInt("usr"));
                                        editor.commit();
                                        startActivity(in);
                                        finish();
                                    } else {
                                        user.setText("");
                                        pass.setText("");
                                    }
                                } catch (JSONException e) {
                                    throw new RuntimeException(e);
                                }
                                Toast.makeText(RealMain.this, response.toString(), Toast.LENGTH_SHORT).show();
                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d("yo", error.getMessage());
                    }
                });
        RequestQueue lanzarPeticion = Volley.newRequestQueue(this);
        lanzarPeticion.add(pet);
    }
}