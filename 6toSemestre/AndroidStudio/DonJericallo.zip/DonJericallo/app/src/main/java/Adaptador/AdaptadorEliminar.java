package Adaptador;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.donjericallo.R;

import Global.Info;

public class AdaptadorEliminar extends RecyclerView.Adapter<AdaptadorEliminar.Myactivity>
{
    public Context context;

    @NonNull
    @Override
    public AdaptadorEliminar.Myactivity onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = View.inflate(context, R.layout.listota, null);
        return new Myactivity(v);
    }

    @Override
    public void onBindViewHolder(@NonNull AdaptadorEliminar.Myactivity holder, int i) {
        final int pos = i;
        holder.text1.setText(Info.lista.get(i).getNombre());
        holder.text2.setText(Info.lista.get(i).getTipo());
        holder.seleccion.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                if(((CheckBox)view).isChecked())
                {
                    Info.ListaBaja.add(Info.lista.get(pos));
                }
                else
                {
                    Info.ListaBaja.remove(Info.lista.get(pos));
                }
            }
        });
    }

    @Override
    public int getItemCount() { return Info.lista.size(); }

    public class Myactivity extends RecyclerView.ViewHolder
    {
        TextView text1, text2;
        CheckBox seleccion;
        public Myactivity(@NonNull View itemView) {
            super(itemView);

            text1 = itemView.findViewById(R.id.Nombre);
            text2 = itemView.findViewById(R.id.Tipo);
            seleccion = itemView.findViewById(R.id.chk_seleccion);
        }
    }
}
