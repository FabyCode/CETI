package com.example.xml;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import adaptador.adaptadorver;

public class recycler extends AppCompatActivity
{
    RecyclerView rv;
    Toolbar toolbar;
    SharedPreferences archivo;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycler);

        rv = findViewById(R.id.recycler);
        adaptadorver av = new adaptadorver();
        av.context = this;
        LinearLayoutManager llm = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        rv.setAdapter(av);
        rv.setLayoutManager(llm);
        archivo=this.getSharedPreferences("sesion", Context.MODE_PRIVATE);
        toolbar=findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

    }
    public boolean onCreateOptionsMenu (Menu menu)
    {
        getMenuInflater().inflate(R.menu.menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item)
    {
        if(item.getItemId() == R.id.help)
        {
            Toast.makeText(recycler.this,"Ya se encuentra en la activity", Toast.LENGTH_SHORT).show();
        }
        if(item.getItemId() == R.id.creator)
        {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }
        if(item.getItemId() == R.id.opc2)
        {
            Intent modi = new Intent(this, mod.class);
            startActivity(modi);
        }
        if(item.getItemId() == R.id.opc3)
        {
            Intent delete = new Intent(this, eliminar.class);
            startActivity(delete);
        }
        if(item.getItemId() == R.id.opc4)
        {
            if(archivo.contains("id_usuario")){
                SharedPreferences.Editor editor = archivo.edit();
                editor.remove("id_usuario");
                editor.commit();
                Intent fin = new Intent(this, inicio.class);
                startActivity(fin);
                finish();
            }
            /*if(archivo.contains("user") && archivo.contains("pass"))
            {
                SharedPreferences.Editor editor= archivo.edit();
                editor.remove("user");
                editor.remove("pass");
                editor.remove("valido");
                editor.commit();
                Intent fin = new Intent(this, inicio.class);
                startActivity(fin);
                finish();
            }*/
        }
        return super.onOptionsItemSelected(item);
    }
}