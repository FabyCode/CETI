package com.example.xml;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import global.info;

public class Card extends AppCompatActivity
{
    TextView nom, tipo, can,  tam, tel;
    Button boton;
    int posicion;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_card);

        nom = findViewById(R.id.CardNom);
        tipo = findViewById(R.id.CardTipo);
        can = findViewById(R.id.CardCant);
        tam = findViewById(R.id.CardTam);
        tel = findViewById(R.id.CardTel);
        boton = findViewById(R.id.botoncall);

        boton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                onclickllamar();
            }
        });

        posicion = getIntent().getIntExtra("pos", -1);
        nom.setText(info.lista.get(posicion).getNombre());
        tipo.setText(info.lista.get(posicion).getTipo());
        can.setText(info.lista.get(posicion).getCantidad());
        tam.setText(info.lista.get(posicion).getTamano());
        tel.setText(info.lista.get(posicion).getContacto());
    }

    private void onclickllamar()
    {
        Intent llamar = new Intent(Intent.ACTION_CALL);
        llamar.setData(Uri.parse("tel:"+tel.getText().toString()));
        if(ActivityCompat.checkSelfPermission
                (this, Manifest.permission.CALL_PHONE)
                != PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(this, new String[]
                    {Manifest.permission.CALL_PHONE}, 10);
            return;
        }
        startActivity(llamar);
    }
}