package com.example.xml;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.widget.Toolbar;

import global.info;
import pojo.pedidos;

public class MainActivity extends AppCompatActivity {

    EditText e1,e2,e3,e4, e5;
    Toolbar toolbar;
    Button boton;
    SharedPreferences archivo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        e1=findViewById(R.id.edit1);
        e2=findViewById(R.id.edit2);
        e3=findViewById(R.id.edit3);
        e4=findViewById(R.id.edit4);
        e5=findViewById(R.id.edit5);
        boton=findViewById(R.id.boton);
        toolbar=findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        archivo=this.getSharedPreferences("sesion", Context.MODE_PRIVATE);

        boton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                agregar();
            }
        });
    }

    public boolean onCreateOptionsMenu (Menu menu)
    {
        getMenuInflater().inflate(R.menu.menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item)
    {
        if(item.getItemId() == R.id.help)
        {
            Intent intent = new Intent(this, recycler.class);
            startActivity(intent);
        }
        if(item.getItemId() == R.id.creator)
        {
            Toast.makeText(MainActivity.this, "Ya se encuentra en la activity", Toast.LENGTH_SHORT).show();
        }
        if(item.getItemId() == R.id.opc2)
        {
            Intent modi = new Intent(this, mod.class);
            startActivity(modi);
        }
        if(item.getItemId() == R.id.opc3)
        {
            Intent delete = new Intent(this, eliminar.class);
            startActivity(delete);
        }
        if(item.getItemId() == R.id.opc4)
        {
            if(archivo.contains("id_usuario")){
                SharedPreferences.Editor editor = archivo.edit();
                editor.remove("id_usuario");
                editor.commit();
                Intent fin = new Intent(this, inicio.class);
                startActivity(fin);
                finish();
            }
            /*if(archivo.contains("user") && archivo.contains("pass"))
            {
                SharedPreferences.Editor editor= archivo.edit();
                editor.remove("user");
                editor.remove("pass");
                editor.remove("valido");
                editor.commit();
                Intent fin = new Intent(this, inicio.class);
                startActivity(fin);
                finish();
            }*/
        }
        return super.onOptionsItemSelected(item);
    }


    private void agregar()
    {
        pedidos gelatina = new pedidos();
        gelatina.setNombre(e1.getText().toString());
        gelatina.setTipo(e2.getText().toString());
        gelatina.setTamano(e3.getText().toString());
        gelatina.setCantidad(e4.getText().toString());
        gelatina.setContacto(e5.getText().toString());

        info.lista.add(gelatina);

        Toast.makeText(MainActivity.this, "Pedido añadido", Toast.LENGTH_SHORT).show();
    }

}