package global;

import java.util.ArrayList;
import pojo.pedidos;

public class info
{
    public static final ArrayList<pedidos> lista = new ArrayList<>();
    public static final ArrayList<pedidos> ListaBaja = new ArrayList<>();
}
