package adaptador;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.xml.Card;
import com.example.xml.R;

import java.util.Objects;

import global.info;

public class AdaptadorEliminar extends RecyclerView.Adapter<AdaptadorEliminar.Myactivity>
{
    public Context context;

    @NonNull
    @Override
    public AdaptadorEliminar.Myactivity onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = View.inflate(context,R.layout.bajas, null);
        return new Myactivity(v);
    }

    @Override
    public void onBindViewHolder(@NonNull AdaptadorEliminar.Myactivity holder, int i)
    {
        final int pos = i;
        holder.text1.setText(info.lista.get(i).getNombre());
        holder.text2.setText(info.lista.get(i).getTipo());
        holder.seleccion.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                if(((CheckBox)view).isChecked())
                {
                    info.ListaBaja.add(info.lista.get(pos));
                }
                else
                {
                    info.ListaBaja.remove(info.lista.get(pos));
                }
            }
        });
    }

    @Override
    public int getItemCount() { return info.lista.size(); }


    public class Myactivity extends RecyclerView.ViewHolder
    {
        TextView text1, text2;
        CheckBox seleccion;
        public Myactivity(@NonNull View itemView) {
            super(itemView);

            text1 = itemView.findViewById(R.id.Nombre);
            text2 = itemView.findViewById(R.id.Tipo);
            seleccion = itemView.findViewById(R.id.chk_seleccion);
        }
    }
}
