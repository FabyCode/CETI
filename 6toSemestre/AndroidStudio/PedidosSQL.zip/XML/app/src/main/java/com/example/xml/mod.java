package com.example.xml;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.xml.MainActivity;
import com.example.xml.R;
import com.example.xml.eliminar;
import com.example.xml.recycler;

import adaptador.adaptadorver;
import global.info;
import pojo.pedidos;

public class mod extends AppCompatActivity {

    EditText nom, canti, tam, tel, tipo;
    Button next, back, guardar;
    Toolbar toolbar;
    int posicion;
    pedidos Persona;
    SharedPreferences archivo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mod);
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        nom = findViewById(R.id.edit1);
        tipo = findViewById(R.id.edit2);
        tam = findViewById(R.id.edit3);
        canti = findViewById(R.id.edit4);
        tel = findViewById(R.id.edit5);
        archivo=this.getSharedPreferences("sesion", Context.MODE_PRIVATE);
        next = findViewById(R.id.siguiente);
        back = findViewById(R.id.anterior);
        guardar = findViewById(R.id.save);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onClickSiguiente();
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onClickAnterior();
            }
        });

        guardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onClickGuardar();
            }
        });

        posicion = 0;
        if (info.lista.size() > 0) {
            Persona = info.lista.get(0);
            imprime(Persona);
        }
    }

    private void imprime(pedidos x)
    {
        nom.setText(x.getNombre());
        tipo.setText(x.getTipo());
        tam.setText(x.getTamano());
        canti.setText(x.getCantidad());
        tel.setText(x.getContacto());
    }

    private void onClickGuardar()
    {
        if(info.lista.size() > 0) {
            Persona.setNombre(nom.getText().toString());
            Persona.setCantidad(canti.getText().toString());
            Persona.setContacto(tel.getText().toString());
            Persona.setTipo(tipo.getText().toString());
            Persona.setTamano(tam.getText().toString());
        }
    }

    private void onClickAnterior()
    {
        if(info.lista.size() > 0) {
            if (posicion == 0) {
                posicion = info.lista.size() - 1;
            } else {
                posicion--;
            }
            Persona = info.lista.get(posicion);
            imprime(Persona);
        }
    }
    private void onClickSiguiente()
    {
        if(info.lista.size() > 0) {
            if (posicion == info.lista.size() - 1){
                posicion = 0;
            }else {
                posicion++;
            }
            Persona = info.lista.get(posicion);
            imprime(Persona);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.help)
        {
            Intent intent = new Intent(this, recycler.class);
            startActivity(intent);
        }
        if(item.getItemId() == R.id.creator)
        {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }
        if(item.getItemId() == R.id.opc2)
        {
            Toast.makeText(this, "Ya estás aquí", Toast.LENGTH_SHORT).show();
        }
        if(item.getItemId() == R.id.opc3)
        {
            Intent delete = new Intent(this, eliminar.class);
            startActivity(delete);
        }
        if(item.getItemId() == R.id.opc4)
        {
            if(archivo.contains("id_usuario")){
                SharedPreferences.Editor editor = archivo.edit();
                editor.remove("id_usuario");
                editor.commit();
                Intent fin = new Intent(this, inicio.class);
                startActivity(fin);
                finish();
            }
            /*if(archivo.contains("user") && archivo.contains("pass"))
            {
                SharedPreferences.Editor editor= archivo.edit();
                editor.remove("user");
                editor.remove("pass");
                editor.remove("valido");
                editor.commit();
                Intent fin = new Intent(this, inicio.class);
                startActivity(fin);
                finish();
            }*/
        }
        return super.onOptionsItemSelected(item);
    }

}