package adaptador;

import android.content.Context;
import android.content.Intent;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.example.xml.Card;
import com.example.xml.R;

import java.util.zip.Inflater;

import global.info;

public class adaptadorver extends RecyclerView.Adapter<adaptadorver.MiActivity>
{
    public Context context;

    @NonNull
    @Override
    public adaptadorver.MiActivity onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        View v = View.inflate(context, R.layout.mi_lista, null);
        //View v = View.inflate(context, R.layout.activity_card, null);
        MiActivity obj = new MiActivity(v);
        return obj;
    }

    @Override
    public void onBindViewHolder(@NonNull adaptadorver.MiActivity holder, int i)
    {
        final int pos = i;

        holder.nom.setText((info.lista.get(i).getNombre()));
        holder.ped.setText((info.lista.get(i).getTipo()));
        /*holder.can.setText((info.lista.get(i).getCantidad()));
        holder.tam.setText((info.lista.get(i).getTamano()));
        holder.tel.setText((info.lista.get(i).getContacto()));*/

        holder.nom.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View view) {
                Intent card = new Intent(context, Card.class);
                card.putExtra("pos",pos);
                context.startActivity(card);
            }
        });
    }

    @Override
    public int getItemCount()
    {
        return info.lista.size();
    }

    public class MiActivity extends RecyclerView.ViewHolder
    {
        TextView nom, ped, can, tam, tel;
        public MiActivity(@NonNull View itemView)
        {
            super(itemView);
            nom = itemView.findViewById(R.id.nom);
            ped = itemView.findViewById(R.id.pedi);

            /*nom=itemView.findViewById(R.id.CardNom);
            ped=itemView.findViewById(R.id.CardTipo);
            can=itemView.findViewById(R.id.CardCant);
            tam=itemView.findViewById(R.id.CardTam);
            tel=itemView.findViewById(R.id.CardTel);*/
        }
    }
}
